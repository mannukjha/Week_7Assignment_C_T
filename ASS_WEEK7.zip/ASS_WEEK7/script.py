from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import re
import os

# Initialize Spark session
spark = SparkSession.builder \
    .appName("Daily File Loader") \
    .enableHiveSupport() \
    .getOrCreate()

# Define the path to your data lake folder
data_lake_path = "/mnt/data_lake/"
files = os.listdir(data_lake_path)

# Loop through each file
for file in files:
    file_path = os.path.join(data_lake_path, file)

    # Process CUST_MSTR files
    if file.startswith("CUST_MSTR"):
        match = re.search(r"CUST_MSTR_(\d{8})", file)
        if match:
            date_raw = match.group(1)
            date_fmt = f"{date_raw[:4]}-{date_raw[4:6]}-{date_raw[6:]}"
            df = spark.read.csv(file_path, header=True)
            df = df.withColumn("load_date", lit(date_fmt))
            spark.sql("TRUNCATE TABLE CUST_MSTR")
            df.write.mode("append").saveAsTable("CUST_MSTR")

    elif file.startswith("master_child_export"):
        match = re.search(r"master_child_export-(\d{8})", file)
        if match:
            date_raw = match.group(1)
            date_fmt = f"{date_raw[:4]}-{date_raw[4:6]}-{date_raw[6:]}"
            df = spark.read.csv(file_path, header=True)
            df = df.withColumn("load_date", lit(date_fmt)) \
                   .withColumn("date_key", lit(date_raw))
            spark.sql("TRUNCATE TABLE master_child")
            df.write.mode("append").saveAsTable("master_child")

    # Process H_ECOM_ORDER files
    elif file.startswith("H_ECOM_ORDER"):
        df = spark.read.csv(file_path, header=True)
        spark.sql("TRUNCATE TABLE H_ECOM_Orders")
        df.write.mode("append").saveAsTable("H_ECOM_Orders")
